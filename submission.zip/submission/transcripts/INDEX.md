# Transcript Index

| Approved surface | Exact model identifier | Reasoning/thinking setting | Purpose | Session/thread ID | Parent ID | Native export path |
|---|---|---|---|---|---|---|
| Qwen Code CLI | qwen2.5-coder | not exposed | Core implementation & Full-stack dashboard | qwen-session-1 | not delegated | transcripts/native/qwen/session.md |
